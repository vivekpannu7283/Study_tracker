## To run the Hello World demo:
```sh
flutter run
```
## To run the Hello World demo showing Arabic:
```sh
flutter run lib/arabic.dart
```
